#include "intro.h"

bool cc(int x, int y);

void maze_init();
void maze_generate(int x, int y);
bool** setup();
